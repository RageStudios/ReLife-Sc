/*    */ package mc.relife.java.procedures;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import mc.relife.java.RelifeMod;
/*    */ import mc.relife.java.init.RelifeModItems;
/*    */ import net.minecraft.class_1263;
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_1657;
/*    */ import net.minecraft.class_1799;
/*    */ import net.minecraft.class_1934;
/*    */ import net.minecraft.class_1935;
/*    */ import net.minecraft.class_1936;
/*    */ import net.minecraft.class_2561;
/*    */ import net.minecraft.class_3222;
/*    */ import net.minecraft.class_342;
/*    */ 
/*    */ public class TakeNameProcedure
/*    */ {
/*    */   public static void execute(Map<String, Object> dependencies) {
/* 23 */     if (dependencies.get("world") == null) {
/* 24 */       if (!dependencies.containsKey("world"))
/* 25 */         RelifeMod.LOGGER.warn("Failed to load dependency world for procedure TakeName!"); 
/*    */       return;
/*    */     } 
/* 28 */     if (dependencies.get("entity") == null) {
/* 29 */       if (!dependencies.containsKey("entity"))
/* 30 */         RelifeMod.LOGGER.warn("Failed to load dependency entity for procedure TakeName!"); 
/*    */       return;
/*    */     } 
/* 33 */     if (dependencies.get("guistate") == null) {
/* 34 */       if (!dependencies.containsKey("guistate"))
/* 35 */         RelifeMod.LOGGER.warn("Failed to load dependency guistate for procedure TakeName!"); 
/*    */       return;
/*    */     } 
/* 38 */     class_1936 world = (class_1936)dependencies.get("world");
/* 39 */     class_1297 entity = (class_1297)dependencies.get("entity");
/* 40 */     HashMap guistate = (HashMap)dependencies.get("guistate");
/*    */     
/* 42 */     List<? extends class_1657> _players = new ArrayList<>(world.method_18456());
/* 43 */     for (class_1297 entityiterator : _players) {
/* 44 */       if (entityiterator.method_5476().getString()
/* 45 */         .equals(guistate.containsKey("text:NameBox") ? ((class_342)guistate.get("text:NameBox")).method_1882() : "")) {
/*    */         
/* 47 */         class_1297 _ent = entityiterator;
/* 48 */         _ent.method_5859(entity.method_23317(), entity.method_23318(), entity.method_23321());
/* 49 */         if (_ent instanceof class_3222) { class_3222 _serverPlayer = (class_3222)_ent;
/* 50 */           _serverPlayer.field_13987.method_14363(entity.method_23317(), entity.method_23318(), entity.method_23321(), _ent.method_36454(), _ent.method_36455()); }
/*    */         
/* 52 */         if (entityiterator instanceof class_3222) { class_3222 _player = (class_3222)entityiterator;
/* 53 */           _player.method_7336(class_1934.field_9215); }
/* 54 */          if (entity instanceof class_3222) { class_3222 _player = (class_3222)entity;
/* 55 */           _player.method_7346(); }
/* 56 */          if (entity instanceof class_1657) { class_1657 _player = (class_1657)entity;
/* 57 */           class_1799 _stktoremove = new class_1799((class_1935)RelifeModItems.RESURRECTOR);
/* 58 */           _player.method_31548().method_29280(p -> (_stktoremove.method_7909() == p.method_7909()), 1, (class_1263)_player.field_7498
/* 59 */               .method_29281()); }
/*    */          continue;
/*    */       } 
/* 62 */       if (entity instanceof class_1657) { class_1657 _player = (class_1657)entity; if (!_player.field_6002.method_8608())
/* 63 */           _player.method_7353((class_2561)class_2561.method_43470("Player Not Found"), true);  }
/*    */     
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Robin\Downloads\relife-alpha-1.1-1.19.2.jar!\mc\relife\java\procedures\TakeNameProcedure.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */