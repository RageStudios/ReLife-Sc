/*    */ package mc.relife.java.procedures;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_1657;
/*    */ import net.minecraft.class_1799;
/*    */ import net.minecraft.class_1802;
/*    */ import net.minecraft.class_1935;
/*    */ import net.minecraft.class_1937;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_2586;
/*    */ import net.minecraft.class_2680;
/*    */ import net.minecraft.class_2960;
/*    */ import net.minecraft.class_3222;
/*    */ 
/*    */ public class UnlockResurrectorProcedure {
/*    */   public UnlockResurrectorProcedure() {
/* 19 */     PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockentity) -> {
/*    */           Map<String, Object> dependencies = new HashMap<>();
/*    */           dependencies.put("x", Integer.valueOf(pos.method_10263()));
/*    */           dependencies.put("y", Integer.valueOf(pos.method_10264()));
/*    */           dependencies.put("z", Integer.valueOf(pos.method_10260()));
/*    */           dependencies.put("px", Double.valueOf(player.method_23317()));
/*    */           dependencies.put("py", Double.valueOf(player.method_23318()));
/*    */           dependencies.put("pz", Double.valueOf(player.method_23321()));
/*    */           dependencies.put("blockstate", state);
/*    */           dependencies.put("world", world);
/*    */           dependencies.put("entity", player);
/*    */           execute(dependencies);
/*    */           return true;
/*    */         });
/*    */   }
/*    */   
/*    */   public static void execute(Map<String, Object> dependencies) {
/* 36 */     if (dependencies.get("entity") == null) {
/* 37 */       if (!dependencies.containsKey("entity"))
/* 38 */         RelifeMod.LOGGER.warn("Failed to load dependency entity for procedure UnlockResurrector!"); 
/*    */       return;
/*    */     } 
/* 41 */     class_1297 entity = (class_1297)dependencies.get("entity");
/* 42 */     class_1657 _playerHasItem = (class_1657)entity; if (entity instanceof class_1657 && _playerHasItem.method_31548().method_7379(new class_1799((class_1935)class_1802.field_8477)) && 
/* 43 */       entity instanceof class_3222) { class_3222 _serverPlayer = (class_3222)entity;
/* 44 */       _serverPlayer.method_7335(new class_2960[] { new class_2960("resurrector_recipe") }); }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\Robin\Downloads\relife-alpha-1.1-1.19.2.jar!\mc\relife\java\procedures\UnlockResurrectorProcedure.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */