/*    */ package mc.relife.java;
/*    */ 
/*    */ import mc.relife.java.init.RelifeModScreens;
/*    */ import net.fabricmc.api.ClientModInitializer;
/*    */ import net.fabricmc.api.EnvType;
/*    */ import net.fabricmc.api.Environment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Environment(EnvType.CLIENT)
/*    */ public class ClientInit
/*    */   implements ClientModInitializer
/*    */ {
/*    */   public void onInitializeClient() {
/* 26 */     RelifeModScreens.load();
/*    */   }
/*    */ }


/* Location:              C:\Users\Robin\Downloads\relife-alpha-1.1-1.19.2.jar!\mc\relife\java\ClientInit.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */