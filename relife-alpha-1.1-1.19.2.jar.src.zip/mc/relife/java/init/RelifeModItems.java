/*    */ package mc.relife.java.init;
/*    */ 
/*    */ import mc.relife.java.item.ResurrectorItem;
/*    */ import net.minecraft.class_1792;
/*    */ import net.minecraft.class_2378;
/*    */ import net.minecraft.class_2960;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RelifeModItems
/*    */ {
/*    */   public static class_1792 RESURRECTOR;
/*    */   
/*    */   public static void load() {
/* 18 */     RESURRECTOR = (class_1792)class_2378.method_10230((class_2378)class_2378.field_11142, new class_2960("relife", "resurrector"), new ResurrectorItem());
/*    */   }
/*    */ }


/* Location:              C:\Users\Robin\Downloads\relife-alpha-1.1-1.19.2.jar!\mc\relife\java\init\RelifeModItems.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */