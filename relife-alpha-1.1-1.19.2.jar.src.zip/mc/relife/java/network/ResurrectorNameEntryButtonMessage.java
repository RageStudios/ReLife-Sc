/*    */ package mc.relife.java.network;
/*    */ 
/*    */ import com.google.common.collect.ImmutableMap;
/*    */ import io.netty.buffer.Unpooled;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import mc.relife.java.procedures.TakeNameProcedure;
/*    */ import mc.relife.java.world.inventory.ResurrectorNameEntryMenu;
/*    */ import net.fabricmc.fabric.api.networking.v1.PacketSender;
/*    */ import net.minecraft.class_2540;
/*    */ import net.minecraft.class_3218;
/*    */ import net.minecraft.class_3222;
/*    */ import net.minecraft.class_3244;
/*    */ import net.minecraft.server.MinecraftServer;
/*    */ 
/*    */ 
/*    */ public class ResurrectorNameEntryButtonMessage
/*    */   extends class_2540
/*    */ {
/*    */   public ResurrectorNameEntryButtonMessage(int buttonID, int x, int y, int z) {
/* 21 */     super(Unpooled.buffer());
/* 22 */     writeInt(buttonID);
/* 23 */     writeInt(x);
/* 24 */     writeInt(y);
/* 25 */     writeInt(z);
/*    */   }
/*    */ 
/*    */   
/*    */   public static void apply(MinecraftServer server, class_3222 entity, class_3244 handler, class_2540 buf, PacketSender responseSender) {
/* 30 */     int buttonID = buf.readInt();
/* 31 */     double x = buf.readInt();
/* 32 */     double y = buf.readInt();
/* 33 */     double z = buf.readInt();
/* 34 */     server.execute(() -> {
/*    */           class_3218 class_3218 = entity.method_14220();
/*    */           HashMap guistate = ResurrectorNameEntryMenu.guistate;
/*    */           if (buttonID == 0)
/*    */             TakeNameProcedure.execute((Map)ImmutableMap.builder().put("world", class_3218).put("entity", entity).put("guistate", guistate).build()); 
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Users\Robin\Downloads\relife-alpha-1.1-1.19.2.jar!\mc\relife\java\network\ResurrectorNameEntryButtonMessage.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */