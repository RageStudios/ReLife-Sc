/*    */ package mc.relife.java.item;
/*    */ 
/*    */ import com.google.common.collect.ImmutableMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import mc.relife.java.item.inventory.ResurrectorInventory;
/*    */ import mc.relife.java.procedures.ResurrectorRightclickedProcedure;
/*    */ import mc.relife.java.world.inventory.ResurrectorNameEntryMenu;
/*    */ import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
/*    */ import net.minecraft.class_1263;
/*    */ import net.minecraft.class_1268;
/*    */ import net.minecraft.class_1271;
/*    */ import net.minecraft.class_1657;
/*    */ import net.minecraft.class_1661;
/*    */ import net.minecraft.class_1703;
/*    */ import net.minecraft.class_1761;
/*    */ import net.minecraft.class_1792;
/*    */ import net.minecraft.class_1799;
/*    */ import net.minecraft.class_1814;
/*    */ import net.minecraft.class_1836;
/*    */ import net.minecraft.class_1839;
/*    */ import net.minecraft.class_1937;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_2540;
/*    */ import net.minecraft.class_2561;
/*    */ import net.minecraft.class_3222;
/*    */ import net.minecraft.class_3908;
/*    */ 
/*    */ public class ResurrectorItem extends class_1792 {
/*    */   public ResurrectorItem() {
/* 31 */     super((new class_1792.class_1793()).method_7892(class_1761.field_7932).method_7889(1).method_24359().method_7894(class_1814.field_8904));
/*    */   }
/*    */ 
/*    */   
/*    */   public class_1839 method_7853(class_1799 itemstack) {
/* 36 */     return class_1839.field_8946;
/*    */   }
/*    */ 
/*    */   
/*    */   public int method_7881(class_1799 itemstack) {
/* 41 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean method_7886(class_1799 itemstack) {
/* 46 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void method_7851(class_1799 itemstack, class_1937 world, List<class_2561> list, class_1836 flag) {
/* 51 */     super.method_7851(itemstack, world, list, flag);
/* 52 */     list.add(class_2561.method_43470("Resurrect a dead player."));
/*    */   }
/*    */ 
/*    */   
/*    */   public class_1271<class_1799> method_7836(class_1937 world, class_1657 entity, class_1268 hand) {
/* 57 */     class_1271<class_1799> ar = super.method_7836(world, entity, hand);
/* 58 */     final class_1799 itemstack = (class_1799)ar.method_5466();
/* 59 */     double x = entity.method_23317();
/* 60 */     double y = entity.method_23318();
/* 61 */     double z = entity.method_23321();
/* 62 */     entity.method_17355((class_3908)new ExtendedScreenHandlerFactory()
/*    */         {
/*    */           public class_1703 createMenu(int syncId, class_1661 inventory, class_1657 player) {
/* 65 */             return (class_1703)new ResurrectorNameEntryMenu(syncId, inventory, (class_1263)new ResurrectorInventory(itemstack));
/*    */           }
/*    */ 
/*    */           
/*    */           public class_2561 method_5476() {
/* 70 */             return itemstack.method_7954();
/*    */           }
/*    */ 
/*    */           
/*    */           public void writeScreenOpeningData(class_3222 player, class_2540 buf) {
/* 75 */             buf.method_10807(class_2338.field_10980);
/*    */           }
/*    */         });
/*    */     
/* 79 */     ResurrectorRightclickedProcedure.execute((Map)ImmutableMap.builder().put("world", world).put("x", Double.valueOf(x))
/* 80 */         .put("y", Double.valueOf(y)).put("z", Double.valueOf(z)).put("entity", entity).build());
/* 81 */     return ar;
/*    */   }
/*    */ }


/* Location:              C:\Users\Robin\Downloads\relife-alpha-1.1-1.19.2.jar!\mc\relife\java\item\ResurrectorItem.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */