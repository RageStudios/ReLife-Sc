/*    */ package mc.relife.java;
/*    */ 
/*    */ import mc.relife.java.init.RelifeModItems;
/*    */ import mc.relife.java.init.RelifeModMenus;
/*    */ import mc.relife.java.init.RelifeModProcedures;
/*    */ import net.fabricmc.api.ModInitializer;
/*    */ import org.apache.logging.log4j.LogManager;
/*    */ import org.apache.logging.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RelifeMod
/*    */   implements ModInitializer
/*    */ {
/* 25 */   public static final Logger LOGGER = LogManager.getLogger();
/*    */   
/*    */   public static final String MODID = "relife";
/*    */   
/*    */   public void onInitialize() {
/* 30 */     LOGGER.info("Initializing RelifeMod");
/*    */     
/* 32 */     RelifeModItems.load();
/*    */     
/* 34 */     RelifeModProcedures.load();
/*    */     
/* 36 */     RelifeModMenus.load();
/*    */   }
/*    */ }


/* Location:              C:\Users\Robin\Downloads\relife-alpha-1.1-1.19.2.jar!\mc\relife\java\RelifeMod.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */