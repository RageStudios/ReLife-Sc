/*    */ package mc.relife.java.mixins;
/*    */ 
/*    */ import com.google.common.collect.Lists;
/*    */ import java.util.ArrayList;
/*    */ import net.minecraft.class_1715;
/*    */ import net.minecraft.class_1799;
/*    */ import net.minecraft.class_4317;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_4317.class})
/*    */ public abstract class RelifeModRepairItemRecipeMixin
/*    */ {
/*    */   @Inject(method = {"assemble"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void assemble(class_1715 craftingContainer, CallbackInfoReturnable<class_1799> cir) {
/* 22 */     ArrayList<class_1799> list = Lists.newArrayList();
/* 23 */     for (int i = 0; i < craftingContainer.method_5439(); i++) {
/*    */       
/* 25 */       class_1799 itemStack = craftingContainer.method_5438(i);
/* 26 */       if (!itemStack.method_7960())
/*    */       {
/* 28 */         list.add(itemStack);
/*    */       }
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Robin\Downloads\relife-alpha-1.1-1.19.2.jar!\mc\relife\java\mixins\RelifeModRepairItemRecipeMixin.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */