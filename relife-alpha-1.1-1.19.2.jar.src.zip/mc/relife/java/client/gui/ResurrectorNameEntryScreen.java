/*     */ package mc.relife.java.client.gui;
/*     */ 
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import mc.relife.java.network.ResurrectorNameEntryButtonMessage;
/*     */ import mc.relife.java.world.inventory.ResurrectorNameEntryMenu;
/*     */ import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
/*     */ import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
/*     */ import net.minecraft.class_1657;
/*     */ import net.minecraft.class_1661;
/*     */ import net.minecraft.class_1703;
/*     */ import net.minecraft.class_1937;
/*     */ import net.minecraft.class_2540;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_2960;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_327;
/*     */ import net.minecraft.class_342;
/*     */ import net.minecraft.class_364;
/*     */ import net.minecraft.class_4185;
/*     */ import net.minecraft.class_4587;
/*     */ import net.minecraft.class_465;
/*     */ 
/*     */ public class ResurrectorNameEntryScreen
/*     */   extends class_465<ResurrectorNameEntryMenu>
/*     */ {
/*     */   private final class_1937 world;
/*     */   private final int x;
/*     */   private final int y;
/*     */   
/*     */   public ResurrectorNameEntryScreen(ResurrectorNameEntryMenu container, class_1661 inventory, class_2561 text) {
/*  31 */     super((class_1703)container, inventory, text);
/*  32 */     this.world = container.world;
/*  33 */     this.x = container.x;
/*  34 */     this.y = container.y;
/*  35 */     this.z = container.z;
/*  36 */     this.entity = container.entity;
/*  37 */     this.field_2792 = 170;
/*  38 */     this.field_2779 = 69;
/*     */   }
/*     */   private final int z; private final class_1657 entity; class_342 NameBox;
/*  41 */   private static final class_2960 texture = new class_2960("relife:textures/screens/resurrector_name_entry.png");
/*     */ 
/*     */   
/*     */   public void method_25394(class_4587 ms, int mouseX, int mouseY, float partialTicks) {
/*  45 */     method_25420(ms);
/*  46 */     super.method_25394(ms, mouseX, mouseY, partialTicks);
/*  47 */     method_2380(ms, mouseX, mouseY);
/*  48 */     this.NameBox.method_25394(ms, mouseX, mouseY, partialTicks);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void method_2389(class_4587 ms, float partialTicks, int gx, int gy) {
/*  53 */     RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
/*  54 */     RenderSystem.enableBlend();
/*  55 */     RenderSystem.defaultBlendFunc();
/*  56 */     RenderSystem.setShaderTexture(0, texture);
/*  57 */     this; method_25290(ms, this.field_2776, this.field_2800, 0.0F, 0.0F, this.field_2792, this.field_2779, this.field_2792, this.field_2779);
/*  58 */     RenderSystem.disableBlend();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean method_25404(int key, int b, int c) {
/*  63 */     if (key == 256) {
/*  64 */       this.field_22787.field_1724.method_7346();
/*  65 */       return true;
/*     */     } 
/*  67 */     if (this.NameBox.method_25370())
/*  68 */       return this.NameBox.method_25404(key, b, c); 
/*  69 */     return super.method_25404(key, b, c);
/*     */   }
/*     */ 
/*     */   
/*     */   public void method_37432() {
/*  74 */     super.method_37432();
/*  75 */     this.NameBox.method_1865();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void method_2388(class_4587 poseStack, int mouseX, int mouseY) {
/*  80 */     this.field_22793.method_1729(poseStack, "Enter Player Name", 6.0F, 6.0F, -12829636);
/*     */   }
/*     */ 
/*     */   
/*     */   public void method_25419() {
/*  85 */     super.method_25419();
/*  86 */     (class_310.method_1551()).field_1774.method_1462(false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void method_25426() {
/*  91 */     super.method_25426();
/*  92 */     this.field_22787.field_1774.method_1462(true);
/*  93 */     this.NameBox = new class_342(this.field_22793, this.field_2776 + 24, this.field_2800 + 18, 120, 20, (class_2561)class_2561.method_43470("Enter Name"))
/*     */       {
/*     */ 
/*     */ 
/*     */         
/*     */         public void method_1867(String text)
/*     */         {
/* 100 */           super.method_1867(text);
/* 101 */           if (method_1882().isEmpty()) {
/* 102 */             method_1887("Enter Name");
/*     */           } else {
/* 104 */             method_1887(null);
/*     */           } 
/*     */         }
/*     */         
/*     */         public void method_1883(int pos) {
/* 109 */           super.method_1883(pos);
/* 110 */           if (method_1882().isEmpty()) {
/* 111 */             method_1887("Enter Name");
/*     */           } else {
/* 113 */             method_1887(null);
/*     */           }  }
/*     */       };
/* 116 */     ResurrectorNameEntryMenu.guistate.put("text:NameBox", this.NameBox);
/* 117 */     this.NameBox.method_1880(32767);
/* 118 */     method_25429((class_364)this.NameBox);
/* 119 */     method_37063((class_364)new class_4185(this.field_2776 + 60, this.field_2800 + 41, 46, 20, (class_2561)class_2561.method_43470("Done"), e -> ClientPlayNetworking.send(new class_2960("relife:resurrectornameentry_button_0"), (class_2540)new ResurrectorNameEntryButtonMessage(0, this.x, this.y, this.z))));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void screenInit() {
/* 127 */     ServerPlayNetworking.registerGlobalReceiver(new class_2960("relife", "resurrectornameentry_button_0"), ResurrectorNameEntryButtonMessage::apply);
/*     */   }
/*     */ }


/* Location:              C:\Users\Robin\Downloads\relife-alpha-1.1-1.19.2.jar!\mc\relife\java\client\gui\ResurrectorNameEntryScreen.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */