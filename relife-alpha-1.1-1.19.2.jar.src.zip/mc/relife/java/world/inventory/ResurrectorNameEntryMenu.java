/*    */ package mc.relife.java.world.inventory;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import mc.relife.java.init.RelifeModMenus;
/*    */ import net.minecraft.class_1263;
/*    */ import net.minecraft.class_1277;
/*    */ import net.minecraft.class_1657;
/*    */ import net.minecraft.class_1661;
/*    */ import net.minecraft.class_1703;
/*    */ import net.minecraft.class_1799;
/*    */ import net.minecraft.class_1937;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_2540;
/*    */ 
/*    */ 
/*    */ public class ResurrectorNameEntryMenu
/*    */   extends class_1703
/*    */ {
/* 19 */   public static final HashMap<String, Object> guistate = new HashMap<>();
/*    */   
/*    */   public final class_1937 world;
/*    */   
/*    */   public final class_1657 entity;
/*    */   public int x;
/*    */   public int y;
/*    */   
/*    */   public ResurrectorNameEntryMenu(int id, class_1661 inv, class_2540 extraData) {
/* 28 */     this(id, inv, (class_1263)new class_1277(0));
/* 29 */     if (extraData != null) {
/* 30 */       this.pos = extraData.method_10811();
/* 31 */       this.x = this.pos.method_10263();
/* 32 */       this.y = this.pos.method_10264();
/* 33 */       this.z = this.pos.method_10260();
/*    */     } 
/*    */   }
/*    */   public int z; private class_2338 pos; private final class_1263 inventory; private boolean bound = false;
/*    */   public ResurrectorNameEntryMenu(int id, class_1661 inv, class_1263 container) {
/* 38 */     super(RelifeModMenus.RESURRECTOR_NAME_ENTRY, id);
/* 39 */     this.entity = inv.field_7546;
/* 40 */     this.world = inv.field_7546.field_6002;
/* 41 */     this.inventory = container;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean method_7597(class_1657 player) {
/* 46 */     return this.inventory.method_5443(player);
/*    */   }
/*    */ 
/*    */   
/*    */   public class_1799 method_7601(class_1657 player, int slot) {
/* 51 */     return class_1799.field_8037;
/*    */   }
/*    */ }


/* Location:              C:\Users\Robin\Downloads\relife-alpha-1.1-1.19.2.jar!\mc\relife\java\world\inventory\ResurrectorNameEntryMenu.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */