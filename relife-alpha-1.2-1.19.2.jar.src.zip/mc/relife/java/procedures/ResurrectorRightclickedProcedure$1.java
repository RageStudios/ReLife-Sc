/*    */ package mc.relife.java.procedures;
/*    */ 
/*    */ import io.netty.buffer.Unpooled;
/*    */ import mc.relife.java.world.inventory.ResurrectorNameEntryMenu;
/*    */ import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
/*    */ import net.minecraft.class_1657;
/*    */ import net.minecraft.class_1661;
/*    */ import net.minecraft.class_1703;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_2540;
/*    */ import net.minecraft.class_2561;
/*    */ import net.minecraft.class_3222;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   implements ExtendedScreenHandlerFactory
/*    */ {
/* 58 */   final class_2338 _pos = new class_2338(x, y, z);
/*    */ 
/*    */   
/*    */   public void writeScreenOpeningData(class_3222 player, class_2540 buf) {
/* 62 */     buf.method_10807(this._pos);
/*    */   }
/*    */ 
/*    */   
/*    */   public class_2561 method_5476() {
/* 67 */     return (class_2561)class_2561.method_43470("ResurrectorNameEntry");
/*    */   }
/*    */ 
/*    */   
/*    */   public class_1703 createMenu(int syncId, class_1661 inv, class_1657 player) {
/* 72 */     return (class_1703)new ResurrectorNameEntryMenu(syncId, inv, (new class_2540(Unpooled.buffer())).method_10807(this._pos));
/*    */   }
/*    */ }


/* Location:              C:\Users\Robin\Downloads\relife-alpha-1.2-1.19.2.jar!\mc\relife\java\procedures\ResurrectorRightclickedProcedure$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */