/*    */ package mc.relife.java.procedures;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import mc.relife.java.RelifeMod;
/*    */ import mc.relife.java.init.RelifeModItems;
/*    */ import net.minecraft.class_1263;
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_161;
/*    */ import net.minecraft.class_1657;
/*    */ import net.minecraft.class_167;
/*    */ import net.minecraft.class_1799;
/*    */ import net.minecraft.class_1934;
/*    */ import net.minecraft.class_1935;
/*    */ import net.minecraft.class_1936;
/*    */ import net.minecraft.class_2561;
/*    */ import net.minecraft.class_2960;
/*    */ import net.minecraft.class_3222;
/*    */ import net.minecraft.class_342;
/*    */ 
/*    */ public class TakeNameProcedure
/*    */ {
/*    */   public static void execute(Map<String, Object> dependencies) {
/* 27 */     if (dependencies.get("world") == null) {
/* 28 */       if (!dependencies.containsKey("world"))
/* 29 */         RelifeMod.LOGGER.warn("Failed to load dependency world for procedure TakeName!"); 
/*    */       return;
/*    */     } 
/* 32 */     if (dependencies.get("entity") == null) {
/* 33 */       if (!dependencies.containsKey("entity"))
/* 34 */         RelifeMod.LOGGER.warn("Failed to load dependency entity for procedure TakeName!"); 
/*    */       return;
/*    */     } 
/* 37 */     if (dependencies.get("guistate") == null) {
/* 38 */       if (!dependencies.containsKey("guistate"))
/* 39 */         RelifeMod.LOGGER.warn("Failed to load dependency guistate for procedure TakeName!"); 
/*    */       return;
/*    */     } 
/* 42 */     class_1936 world = (class_1936)dependencies.get("world");
/* 43 */     class_1297 entity = (class_1297)dependencies.get("entity");
/* 44 */     HashMap guistate = (HashMap)dependencies.get("guistate");
/*    */     
/* 46 */     List<? extends class_1657> _players = new ArrayList<>(world.method_18456());
/* 47 */     for (class_1297 entityiterator : _players) {
/* 48 */       if (entityiterator.method_5476().getString()
/* 49 */         .equals(guistate.containsKey("text:NameBox") ? ((class_342)guistate.get("text:NameBox")).method_1882() : "")) {
/*    */         
/* 51 */         class_1297 _ent = entityiterator;
/* 52 */         _ent.method_5859(entity.method_23317(), entity.method_23318(), entity.method_23321());
/* 53 */         if (_ent instanceof class_3222) { class_3222 _serverPlayer = (class_3222)_ent;
/* 54 */           _serverPlayer.field_13987.method_14363(entity.method_23317(), entity.method_23318(), entity.method_23321(), _ent.method_36454(), _ent.method_36455()); }
/*    */         
/* 56 */         if (entityiterator instanceof class_3222) { class_3222 _player = (class_3222)entityiterator;
/* 57 */           _player.method_7336(class_1934.field_9215); }
/* 58 */          if (entity instanceof class_3222) { class_3222 _player = (class_3222)entity;
/* 59 */           _player.method_7346(); }
/* 60 */          if (entity instanceof class_1657) { class_1657 _player = (class_1657)entity;
/* 61 */           class_1799 _stktoremove = new class_1799((class_1935)RelifeModItems.RESURRECTOR);
/* 62 */           _player.method_31548().method_29280(p -> (_stktoremove.method_7909() == p.method_7909()), 1, (class_1263)_player.field_7498
/* 63 */               .method_29281()); }
/*    */         
/* 65 */         if (entity instanceof class_3222) { class_3222 _player = (class_3222)entity;
/* 66 */           class_161 _adv = _player.field_13995.method_3851().method_12896(new class_2960("relife:revive_a_player"));
/* 67 */           class_167 _ap = _player.method_14236().method_12882(_adv);
/* 68 */           if (!_ap.method_740()) {
/* 69 */             Iterator<String> _iterator = _ap.method_731().iterator();
/* 70 */             while (_iterator.hasNext())
/* 71 */               _player.method_14236().method_12878(_adv, _iterator.next()); 
/*    */           }  }
/*    */          continue;
/*    */       } 
/* 75 */       if (entity instanceof class_1657) { class_1657 _player = (class_1657)entity; if (!_player.field_6002.method_8608())
/* 76 */           _player.method_7353((class_2561)class_2561.method_43470("Player Not Found"), true);  }
/*    */     
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Robin\Downloads\relife-alpha-1.2-1.19.2.jar!\mc\relife\java\procedures\TakeNameProcedure.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */