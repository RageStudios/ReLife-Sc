/*     */ package mc.relife.java.client.gui;
/*     */ 
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_327;
/*     */ import net.minecraft.class_342;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class null
/*     */   extends class_342
/*     */ {
/*     */   null(class_327 font, int i, int j, int k, int l, class_2561 component) {
/*  93 */     super(font, i, j, k, l, component);
/*     */     
/*  95 */     method_1887("Enter Name");
/*     */   }
/*     */ 
/*     */   
/*     */   public void method_1867(String text) {
/* 100 */     super.method_1867(text);
/* 101 */     if (method_1882().isEmpty()) {
/* 102 */       method_1887("Enter Name");
/*     */     } else {
/* 104 */       method_1887(null);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void method_1883(int pos) {
/* 109 */     super.method_1883(pos);
/* 110 */     if (method_1882().isEmpty()) {
/* 111 */       method_1887("Enter Name");
/*     */     } else {
/* 113 */       method_1887(null);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Robin\Downloads\relife-alpha-1.2-1.19.2.jar!\mc\relife\java\client\gui\ResurrectorNameEntryScreen$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */