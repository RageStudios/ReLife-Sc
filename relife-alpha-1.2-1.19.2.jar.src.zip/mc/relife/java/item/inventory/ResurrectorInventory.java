/*     */ package mc.relife.java.item.inventory;
/*     */ 
/*     */ import java.util.List;
/*     */ import net.fabricmc.api.EnvType;
/*     */ import net.fabricmc.api.Environment;
/*     */ import net.minecraft.class_1262;
/*     */ import net.minecraft.class_1278;
/*     */ import net.minecraft.class_1657;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_2371;
/*     */ import net.minecraft.class_2487;
/*     */ import org.jetbrains.annotations.Nullable;
/*     */ 
/*     */ @Environment(EnvType.CLIENT)
/*     */ public class ResurrectorInventory
/*     */   implements class_1278
/*     */ {
/*     */   private final class_1799 stack;
/*  20 */   private final class_2371<class_1799> items = class_2371.method_10213(0, class_1799.field_8037);
/*     */   
/*     */   public ResurrectorInventory(class_1799 stack) {
/*  23 */     this.stack = stack;
/*  24 */     class_2487 tag = stack.method_7941("Items");
/*  25 */     if (tag != null) {
/*  26 */       class_1262.method_5429(tag, this.items);
/*     */     }
/*     */   }
/*     */   
/*     */   public class_2371<class_1799> getItems() {
/*  31 */     return this.items;
/*     */   }
/*     */ 
/*     */   
/*     */   public int[] method_5494(class_2350 side) {
/*  36 */     int[] result = new int[getItems().size()];
/*  37 */     for (int i = 0; i < result.length; i++) {
/*  38 */       result[i] = i;
/*     */     }
/*  40 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public int method_5444() {
/*  45 */     return 64;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean method_5492(int slot, class_1799 stack, @Nullable class_2350 dir) {
/*  50 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean method_5493(int slot, class_1799 stack, class_2350 dir) {
/*  55 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int method_5439() {
/*  60 */     return getItems().size();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean method_5442() {
/*  65 */     for (int i = 0; i < method_5439(); i++) {
/*  66 */       class_1799 stack = method_5438(i);
/*  67 */       if (!stack.method_7960()) {
/*  68 */         return false;
/*     */       }
/*     */     } 
/*  71 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public class_1799 method_5438(int slot) {
/*  76 */     return (class_1799)getItems().get(slot);
/*     */   }
/*     */ 
/*     */   
/*     */   public class_1799 method_5434(int slot, int amount) {
/*  81 */     class_1799 result = class_1262.method_5430((List)getItems(), slot, amount);
/*  82 */     if (!result.method_7960()) {
/*  83 */       method_5431();
/*     */     }
/*  85 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public class_1799 method_5441(int slot) {
/*  90 */     return class_1262.method_5428((List)getItems(), slot);
/*     */   }
/*     */ 
/*     */   
/*     */   public void method_5447(int slot, class_1799 stack) {
/*  95 */     getItems().set(slot, stack);
/*  96 */     if (stack.method_7947() > method_5444()) {
/*  97 */       stack.method_7939(method_5444());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void method_5431() {
/* 103 */     class_2487 tag = this.stack.method_7911("Items");
/* 104 */     class_1262.method_5426(tag, this.items);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean method_5443(class_1657 player) {
/* 109 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void method_5448() {
/* 114 */     getItems().clear();
/*     */   }
/*     */ }


/* Location:              C:\Users\Robin\Downloads\relife-alpha-1.2-1.19.2.jar!\mc\relife\java\item\inventory\ResurrectorInventory.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */