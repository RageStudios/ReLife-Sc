/*    */ package mc.relife.java.item;
/*    */ 
/*    */ import mc.relife.java.item.inventory.ResurrectorInventory;
/*    */ import mc.relife.java.world.inventory.ResurrectorNameEntryMenu;
/*    */ import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
/*    */ import net.minecraft.class_1263;
/*    */ import net.minecraft.class_1657;
/*    */ import net.minecraft.class_1661;
/*    */ import net.minecraft.class_1703;
/*    */ import net.minecraft.class_1799;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_2540;
/*    */ import net.minecraft.class_2561;
/*    */ import net.minecraft.class_3222;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   implements ExtendedScreenHandlerFactory
/*    */ {
/*    */   public class_1703 createMenu(int syncId, class_1661 inventory, class_1657 player) {
/* 60 */     return (class_1703)new ResurrectorNameEntryMenu(syncId, inventory, (class_1263)new ResurrectorInventory(itemstack));
/*    */   }
/*    */ 
/*    */   
/*    */   public class_2561 method_5476() {
/* 65 */     return itemstack.method_7954();
/*    */   }
/*    */ 
/*    */   
/*    */   public void writeScreenOpeningData(class_3222 player, class_2540 buf) {
/* 70 */     buf.method_10807(class_2338.field_10980);
/*    */   }
/*    */ }


/* Location:              C:\Users\Robin\Downloads\relife-alpha-1.2-1.19.2.jar!\mc\relife\java\item\ResurrectorItem$1.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */