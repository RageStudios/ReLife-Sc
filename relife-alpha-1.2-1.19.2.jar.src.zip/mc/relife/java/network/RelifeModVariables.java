/*   */ package mc.relife.java.network;
/*   */ 
/*   */ 
/*   */ public class RelifeModVariables
/*   */ {
/* 6 */   public static String Player = "\"\"";
/*   */ }


/* Location:              C:\Users\Robin\Downloads\relife-alpha-1.2-1.19.2.jar!\mc\relife\java\network\RelifeModVariables.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */