/*    */ package mc.relife.java.init;
/*    */ 
/*    */ import net.fabricmc.fabric.api.client.screenhandler.v1.ScreenRegistry;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RelifeModScreens
/*    */ {
/*    */   public static void load() {
/* 13 */     ScreenRegistry.register(RelifeModMenus.RESURRECTOR_NAME_ENTRY, mc.relife.java.client.gui.ResurrectorNameEntryScreen::new);
/*    */   }
/*    */ }


/* Location:              C:\Users\Robin\Downloads\relife-alpha-1.2-1.19.2.jar!\mc\relife\java\init\RelifeModScreens.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */