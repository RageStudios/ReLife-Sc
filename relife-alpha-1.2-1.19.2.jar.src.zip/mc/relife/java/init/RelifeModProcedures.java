/*    */ package mc.relife.java.init;
/*    */ 
/*    */ import mc.relife.java.procedures.ResurrectorRightclickedProcedure;
/*    */ import mc.relife.java.procedures.TakeNameProcedure;
/*    */ import mc.relife.java.procedures.UnlockResurrectorProcedure;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RelifeModProcedures
/*    */ {
/*    */   public static void load() {
/* 14 */     new ResurrectorRightclickedProcedure();
/* 15 */     new TakeNameProcedure();
/* 16 */     new UnlockResurrectorProcedure();
/*    */   }
/*    */ }


/* Location:              C:\Users\Robin\Downloads\relife-alpha-1.2-1.19.2.jar!\mc\relife\java\init\RelifeModProcedures.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */