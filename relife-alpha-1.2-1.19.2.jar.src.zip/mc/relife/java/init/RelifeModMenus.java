/*    */ package mc.relife.java.init;
/*    */ 
/*    */ import mc.relife.java.client.gui.ResurrectorNameEntryScreen;
/*    */ import mc.relife.java.world.inventory.ResurrectorNameEntryMenu;
/*    */ import net.fabricmc.fabric.api.screenhandler.v1.ScreenHandlerRegistry;
/*    */ import net.minecraft.class_2960;
/*    */ import net.minecraft.class_3917;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RelifeModMenus
/*    */ {
/*    */   public static class_3917<ResurrectorNameEntryMenu> RESURRECTOR_NAME_ENTRY;
/*    */   
/*    */   public static void load() {
/* 20 */     RESURRECTOR_NAME_ENTRY = ScreenHandlerRegistry.registerExtended(new class_2960("relife", "resurrector_name_entry"), ResurrectorNameEntryMenu::new);
/*    */     
/* 22 */     ResurrectorNameEntryScreen.screenInit();
/*    */   }
/*    */ }


/* Location:              C:\Users\Robin\Downloads\relife-alpha-1.2-1.19.2.jar!\mc\relife\java\init\RelifeModMenus.class
 * Java compiler version: 17 (61.0)
 * JD-Core Version:       1.1.3
 */